self.__precacheManifest = [
  {
    "revision": "798cb67a961f1572176b",
    "url": "/preview/xbyjeal4/static/js/runtime~main.43adda2d.js"
  },
  {
    "revision": "b2ff3f6fc8a7c1d4b5c4",
    "url": "/preview/xbyjeal4/static/js/main.642906cc.chunk.js"
  },
  {
    "revision": "3a7c9a6411f8bac93609",
    "url": "/preview/xbyjeal4/static/js/2.640ad799.chunk.js"
  },
  {
    "revision": "b2ff3f6fc8a7c1d4b5c4",
    "url": "/preview/xbyjeal4/static/css/main.0b41a6c7.chunk.css"
  },
  {
    "revision": "ca39bd72e3042fef81bb46cf46762ac1",
    "url": "/preview/xbyjeal4/index.html"
  }
];