self.__precacheManifest = [
  {
    "revision": "798cb67a961f1572176b",
    "url": "/preview/xbyjeal4/static/js/runtime~main.43adda2d.js"
  },
  {
    "revision": "1194724bd8a9d625246a",
    "url": "/preview/xbyjeal4/static/js/main.61f0f60d.chunk.js"
  },
  {
    "revision": "d42466ceff01eefb5f88",
    "url": "/preview/xbyjeal4/static/js/2.3cb60b03.chunk.js"
  },
  {
    "revision": "1194724bd8a9d625246a",
    "url": "/preview/xbyjeal4/static/css/main.6e6c0ce0.chunk.css"
  },
  {
    "revision": "e5e67eb5ea78218b92459fa1c0e4f5ad",
    "url": "/preview/xbyjeal4/index.html"
  }
];